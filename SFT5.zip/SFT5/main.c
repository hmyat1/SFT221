#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include "stringhelp.h"
#include <string.h>

int main(void) {
    char testStr[] = "This is a\n string with embedded newline characters and\n12345 numbers inside it as well 7890";
    struct StringIndex index = indexString(testStr);
    int i;

    printf("LINES\n");
    for (i = 0; i < index.numLines; i++) {
        char* line = getLine(&index, i);
        printf("%s\n", line);
    }

    printf("\nWORDS\n");
    for (i = 0; i < index.numWords; i++) {
        char word[MAX_WORD_SIZE];
        getWord(word, &index, i);
        printf("%s\n", word);
    }

    printf("\nNUMBERS\n");
    for (i = 0; i < index.numNumbers; i++) {
        char number[MAX_WORD_SIZE];
        getNumber(number, &index, i);
        printf("%s\n", number);
    }

    return 0;
}
