
#include "pch.h"
#include "CppUnitTest.h"
#include "customers_r.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace CustTestSuite
{
    // Black Box Test

    TEST_CLASS(BlankLineTest)
    {
    public:
        TEST_METHOD(BlankLineTestMethod)
        {
            // Test case: Input with a blank line for the postal code
            bool result = isValidPostalCode("\n");
            Assert::IsFalse(result);
        }
    };

    //The ValidPostalCodeTest is a black box test, as it verifies 
    //the validity of a postal code without considering the internal implementation details.
    TEST_CLASS(ValidPostalCodeTest)
    {
    public:

        TEST_METHOD(ValidPostalCodeTestMethod)
        {
            bool result = isValidPostalCode("M1V 4K4");
            Assert::IsTrue(result);
        }

    };

    // White Box Test
    // The ConvertToUppercaseTest is a white box test, as it directly tests the 
    //convertToUppercase function and its internal logic.
    TEST_CLASS(ConvertToUppercaseTest)
    {
    public:

        TEST_METHOD(ConvertToUppercaseTestMethod)
        {
            char postalCode[] = "m1v 4k4";
            convertToUppercase(postalCode);
            Assert::AreEqual("M1V 4K4", postalCode);
        }

    };

    // Black Box Test
    // The CustomerInformationTest includes black box tests for different 
    // fields of the Customer structure, verifying the correctness of the input 
    // and assignment operations.
    TEST_CLASS(CustomerInformationTest)
    {
    public:

        TEST_METHOD(FirstNameTest)
        {
            Customer customer;
            strcpy_s(customer.firstName, "John");

            Assert::AreEqual("John", customer.firstName);
        }

        TEST_METHOD(LastNameTest)
        {
            Customer customer;
            strcpy_s(customer.lastName, "Smith");

            Assert::AreEqual("Smith", customer.lastName);
        }

        TEST_METHOD(AddressTest)
        {
            Customer customer;
            strcpy_s(customer.streetAddress, "35 Elm St.");

            Assert::AreEqual("35 Elm St.", customer.streetAddress);
        }

        TEST_METHOD(CityTest)
        {
            Customer customer;
            strcpy_s(customer.city, "Toronto");

            Assert::AreEqual("Toronto", customer.city);
        }

        TEST_METHOD(ProvinceTest)
        {
            Customer customer;
            strcpy_s(customer.province, "ON");

            Assert::AreEqual("ON", customer.province);
        }
    };

}
