
#pragma once
#ifndef CUSTOMERS_R_H
#define CUSTOMERS_R_H

extern "C"
{
#include <customers.h>
}

#endif
