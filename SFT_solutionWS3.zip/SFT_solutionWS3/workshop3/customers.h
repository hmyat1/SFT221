#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <stdbool.h>

#define MAX_LENGTH 100

typedef struct {
    char firstName[MAX_LENGTH];
    char lastName[MAX_LENGTH];
    char streetAddress[MAX_LENGTH];
    char city[MAX_LENGTH];
    char province[MAX_LENGTH];
    char postalCode[MAX_LENGTH];
} Customer;

bool isValidPostalCode(const char* postalCode);
void convertToUppercase(char* str);
Customer enterCustomerInformation();
void printCustomerInformation(const Customer* customer);

#endif  // CUSTOMER_H
