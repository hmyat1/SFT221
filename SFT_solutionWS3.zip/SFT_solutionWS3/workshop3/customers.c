#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "customers.h"

bool isValidPostalCode(const char* postalCode) {
    int i = 0;
    char formattedPostalCode[MAX_LENGTH];

    // Remove spaces and convert to uppercase
    for (int j = 0; postalCode[j] != '\0'; j++) {
        if (!isspace(postalCode[j])) {
            formattedPostalCode[i] = toupper(postalCode[j]);
            i++;
        }
    }
    formattedPostalCode[i] = '\0';

    // Check if the postal code has the correct format
    if (strlen(formattedPostalCode) != 6)
        return false;

    for (int j = 0; j < 6; j++) {
        if ((j % 2 == 0 && !isalpha(formattedPostalCode[j])) ||
            (j % 2 == 1 && !isdigit(formattedPostalCode[j])))
            return false;
    }

    return true;
}

void convertToUppercase(char* str) {
    //for (int i = 0; str[i] != '\0'; i++) {
    str[0] = toupper(str[0]);
    str[2] = toupper(str[2]);
    str[5] = toupper(str[5]);
    //}
}

Customer enterCustomerInformation() {
    Customer customer;

    // Prompt the user to enter the customer information
    printf("Enter your first name: ");
    //fgets(customer.firstName, MAX_LENGTH, stdin);
    while (fgets(customer.firstName, MAX_LENGTH, stdin)) {
        if (customer.firstName[0] != '\n') {
            //I have incorporated the necessary adjustments in all sections of the code 
            //where data is being read, ensuring that the newline character ('\n') is not 
            //treated as part of the input string.
            customer.firstName[strlen(customer.firstName) - 1] = '\0';
            break;
        }
        printf("Invalid Entry: Enter your first name: ");
    }

    printf("Enter your last name: ");
    while (fgets(customer.lastName, MAX_LENGTH, stdin)) {
        if (customer.lastName[0] != '\n') {
            customer.lastName[strlen(customer.lastName) - 1] = '\0';
            break;
        }
        printf("Invalid Entry: Enter your last name: ");
    }

    printf("Enter your street address: ");
    //fgets(customer.streetAddress, MAX_LENGTH, stdin);
    while (fgets(customer.streetAddress, MAX_LENGTH, stdin)) {
        if (customer.streetAddress[0] != '\n') {
            customer.streetAddress[strlen(customer.streetAddress) - 1] = '\0';
            break;
        }
        printf("Invalid Entry: Enter your street address: ");
    }

    printf("Enter your city: ");
    //fgets(customer.city, MAX_LENGTH, stdin);
    while (fgets(customer.city, MAX_LENGTH, stdin)) {
        if (customer.city[0] != '\n') {
            customer.city[strlen(customer.city) - 1] = '\0';
            break;
        }
        printf("Invalid Entry: Enter your city: ");
    }

    printf("Enter your province: ");
    //fgets(customer.province, MAX_LENGTH, stdin);
    while (fgets(customer.province, MAX_LENGTH, stdin)) {
        if (customer.province[0] != '\n') {
            customer.province[strlen(customer.province) - 1] = '\0';
            break;
        }
        printf("Invalid Entry: Enter your province: ");
    }

    printf("Enter your postal code: ");
    while (fgets(customer.postalCode, MAX_LENGTH, stdin)) {
        if (isValidPostalCode(customer.postalCode)) {
            convertToUppercase(customer.postalCode);
            break;
        }
        printf("Invalid Entry: Enter your postal code: ");
    }

    return customer;
}

void printCustomerInformation(const Customer* customer) {
    printf("\nYou entered:\n");
    printf("%s %s\n", customer->firstName, customer->lastName);
    printf("%s,\n", customer->streetAddress);
    printf("%s, %s,\n", customer->city, customer->province);
    printf("%s", customer->postalCode);
}

int main() {
    Customer customer = enterCustomerInformation();
    printCustomerInformation(&customer);

    return 0;
}

