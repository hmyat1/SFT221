#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "stringhelp.h"
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "log4c (1).h"

int main(void)
{
    // Open a log file
    struct Log4cStruct logFile = l4cOpen("logfile.txt", 0);
    char errMsg[L4C_ERROR_MSG_MAX + 1];

    // Check if the log file was opened successfully
    int logStatus = l4cCheck(&logFile, errMsg);
    if (logStatus != 0) {
        // Log the error and exit if the log file couldn't be opened
        l4cError(&logFile, errMsg);
        return 1;
    }
    char testStr[] = "This is a\nstring with embedded newline characters\nand 12345 numbers inside it as well 7890";
    assert(testStr != NULL);
    struct StringIndex index = indexString(testStr);

    // Log the number of lines, words, and numbers
    char logMessage[100]; // Adjust the buffer size as needed
    snprintf(logMessage, sizeof(logMessage), "Number of Lines: %d", getNumberLines(&index));
    l4cInfo(&logFile, logMessage);

    snprintf(logMessage, sizeof(logMessage), "Number of Words: %d", getNumberWords(&index));
    l4cInfo(&logFile, logMessage);

    snprintf(logMessage, sizeof(logMessage), "Number of Numbers: %d", getNumberNumbers(&index));
    l4cInfo(&logFile, logMessage);

    int i;

    

    printf("LINES\n");
    for (i = 0; i < index.numLines; i++)
    {
        printUntil(index.str, index.lineStarts[i], '\n');
        printf("\n");
    }
    printf("\nWORDS\n");
    for (i = 0; i < index.numWords; i++)
    {
        printUntilSpace(index.str, index.wordStarts[i]);
        printf("\n");
    }
    printf("\nNUMBERS\n");
    for (i = 0; i < index.numNumbers; i++)
    {
        printUntilSpace(index.str, index.numberStarts[i]);
        printf("\n");
    }

    // Additional assertions to validate the code
    assert(getNumberLines(&index) == 3);
    assert(getNumberWords(&index) == 14);
    assert(getNumberNumbers(&index) == 2);

    // Close the log file
    l4cClose(&logFile);

    return 0;
}





